感謝你的使用

請將_清理FiveM快取.bat_放在 FiveM Application Data 綠色蝸牛 不要使用管理員權限執行 放入後直接執行


windows系統清理 放哪裡都可以右鍵管理員權限執行 

全由光頭自做 potol#7325


Thank you for using

Put_clean FiveM cache.bat_put FiveM application data green snail do not use administrator privileges to execute directly after joining


Windows system cleanup can be executed with quick administrator privileges wherever it is placed

All made by bald head potol #7325